using UnityEngine;

public class Attractor : MonoBehaviour
{
    public static Vector3 POS = Vector3.zero;
    public Vector3 center = new Vector3(0f, 5.5f, 0f);
    public float sideAmplitude = 2.15f, sideFrequency = 0.34f;
    public float verticalAmplitude = 1.05f, verticalFrequency = 0.58f;
    public float forwardAmplitude = 10.5f, forwardFrequency = 0.12f;
    public float depthAmplitude = 0.7f, depthFrequency = 0.22f;

    void FixedUpdate()
    {
        Vector3 p = center;
        p.x += Mathf.Sin(Time.time * sideFrequency) * sideAmplitude;
        p.y += Mathf.Sin(Time.time * verticalFrequency) * verticalAmplitude;
        p.z += Mathf.Sin(Time.time * forwardFrequency) * forwardAmplitude + Mathf.Cos(Time.time * depthFrequency) * depthAmplitude;
        transform.position = p;
        POS = p;
    }
}
