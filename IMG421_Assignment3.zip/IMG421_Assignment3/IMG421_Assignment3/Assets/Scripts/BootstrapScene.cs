using System.Collections;
using UnityEngine;

public class BootstrapScene : MonoBehaviour
{
    public bool autoBuildScene = true;

    IEnumerator Start()
    {
        if (!autoBuildScene || FindObjectOfType<Spawner>() != null)
            yield break;

        yield return null;

        try
        {
            ConfigureWorld();
            GameObject anchor = new GameObject("BoidAnchor");
            GameObject attractor = BuildPearlAttractor();
            Attractor.POS = attractor.transform.position;

            Camera cam = Camera.main;
            if (cam == null)
            {
                GameObject camObj = new GameObject("Main Camera");
                cam = camObj.AddComponent<Camera>();
                cam.tag = "MainCamera";
            }

            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.02f, 0.18f, 0.24f);
            cam.nearClipPlane = 0.1f;
            cam.farClipPlane = 250f;
            cam.transform.position = new Vector3(0f, 10f, -22f);
            cam.transform.LookAt(Vector3.zero);
            if (cam.GetComponent<LookAtAttractor>() == null)
                cam.gameObject.AddComponent<LookAtAttractor>();

            GameObject oceanAudio = new GameObject("OceanAudio");
            oceanAudio.AddComponent<OceanAudio>();

            GameObject dynamicSpawner = new GameObject("DynamicObstacleSpawner");
            DynamicObstacleSpawner obstacleSpawner = dynamicSpawner.AddComponent<DynamicObstacleSpawner>();
            obstacleSpawner.targetCamera = cam;

            GameObject boidPrefab = BuildJellyfishPrefab();
            boidPrefab.SetActive(false);

            GameObject spawnerGO = new GameObject("Spawner");
            Spawner spawner = spawnerGO.AddComponent<Spawner>();
            spawner.boidPrefab = boidPrefab;
            spawner.boidAnchor = anchor.transform;

            CreateSeaweedCorridor(-7.0f, 7.0f, -18f, 18f, 1.35f);
            CreateSeaweedCrossBarrier(new Vector3(0f, 0f, -8f), 9, 1.2f, true);
            CreateSeaweedCrossBarrier(new Vector3(0f, 0f, 3f), 9, 1.15f, false);
            CreateSeaweedGate(new Vector3(0f, 0f, 11f), 4.25f);
        }
        catch (System.Exception ex)
        {
            Debug.LogError("BootstrapScene failed: " + ex);
            BuildFallbackScene();
        }
    }

    void ConfigureWorld()
    {
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.03f, 0.22f, 0.27f);
        RenderSettings.fogDensity = 0.012f;
        RenderSettings.ambientLight = new Color(0.18f, 0.35f, 0.38f);

        GameObject lightGO = new GameObject("Directional Light");
        Light light = lightGO.AddComponent<Light>();
        light.type = LightType.Directional;
        light.color = new Color(0.7f, 0.9f, 1f);
        light.intensity = 1.1f;
        light.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
        floor.name = "Seafloor";
        floor.transform.position = new Vector3(0f, -2.4f, 0f);
        floor.transform.localScale = new Vector3(6f, 1f, 8f);

        Renderer r = floor.GetComponent<Renderer>();
        if (r != null)
            r.material = WebGLSafeMaterials.CreateLit(new Color(0.19f, 0.24f, 0.17f));

        for (int i = 0; i < 38; i++)
        {
            GameObject deco = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            deco.name = "BackgroundSeaweed";
            deco.transform.position = new Vector3(Random.Range(-28f, 28f), Random.Range(-2.3f, 0f), Random.Range(-34f, 34f));
            deco.transform.localScale = new Vector3(Random.Range(0.12f, 0.25f), Random.Range(1.2f, 3.2f), Random.Range(0.12f, 0.25f));
            deco.transform.rotation = Quaternion.Euler(Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(-12f, 12f));
            deco.AddComponent<SeaweedSway>();

            Renderer d = deco.GetComponent<Renderer>();
            if (d != null)
            {
                Color c = Color.Lerp(new Color(0.05f, 0.25f, 0.12f), new Color(0.1f, 0.38f, 0.18f), Random.value);
                d.material = WebGLSafeMaterials.CreateLit(c);
            }
            Destroy(deco.GetComponent<Collider>());
        }
    }

    GameObject BuildPearlAttractor()
    {
        GameObject root = new GameObject("PearlAttractor");
        GameObject pearl = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        pearl.name = "Pearl";
        pearl.transform.SetParent(root.transform, false);
        pearl.transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);

        Renderer r = pearl.GetComponent<Renderer>();
        if (r != null)
            r.material = WebGLSafeMaterials.CreateLit(new Color(0.72f, 0.95f, 1f), true, 0.9f);
        Destroy(pearl.GetComponent<Collider>());

        GameObject shellA = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        shellA.name = "ShellTop";
        shellA.transform.SetParent(root.transform, false);
        shellA.transform.localPosition = new Vector3(0f, 0.18f, 0f);
        shellA.transform.localScale = new Vector3(1.6f, 0.35f, 1.4f);

        GameObject shellB = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        shellB.name = "ShellBottom";
        shellB.transform.SetParent(root.transform, false);
        shellB.transform.localPosition = new Vector3(0f, -0.22f, 0f);
        shellB.transform.localScale = new Vector3(1.6f, 0.18f, 1.4f);

        Renderer rA = shellA.GetComponent<Renderer>();
        if (rA != null) rA.material = WebGLSafeMaterials.CreateLit(new Color(0.24f, 0.44f, 0.42f));
        Renderer rB = shellB.GetComponent<Renderer>();
        if (rB != null) rB.material = WebGLSafeMaterials.CreateLit(new Color(0.18f, 0.34f, 0.32f));

        Destroy(shellA.GetComponent<Collider>());
        Destroy(shellB.GetComponent<Collider>());
        root.AddComponent<Attractor>();
        return root;
    }

    GameObject BuildJellyfishPrefab()
    {
        GameObject root = new GameObject("JellyfishPrefab_Runtime");
        Rigidbody rb = root.AddComponent<Rigidbody>();
        rb.useGravity = false;
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        rb.interpolation = RigidbodyInterpolation.Interpolate;

        SphereCollider sense = root.AddComponent<SphereCollider>();
        sense.isTrigger = true;

        root.AddComponent<Neighborhood>();
        root.AddComponent<Boid>();
        root.AddComponent<TrailRenderer>();
        root.AddComponent<BoidTrail>();
        root.AddComponent<JellyPulse>();
        root.AddComponent<JellyfishSFX>();
        root.AddComponent<ParticleSystem>();
        root.AddComponent<BubbleEmitter>();

        GameObject bell = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        bell.name = "Bell";
        bell.transform.SetParent(root.transform, false);
        bell.transform.localPosition = Vector3.zero;
        bell.transform.localScale = new Vector3(0.9f, 0.5f, 0.9f);
        Destroy(bell.GetComponent<Collider>());

        GameObject tentacleRoot = new GameObject("Tentacles");
        tentacleRoot.transform.SetParent(root.transform, false);
        tentacleRoot.transform.localPosition = new Vector3(0f, -0.35f, 0f);

        for (int i = 0; i < 5; i++)
        {
            GameObject tentacle = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            tentacle.name = "Tentacle_" + i;
            tentacle.transform.SetParent(tentacleRoot.transform, false);
            float angle = i * Mathf.PI * 2f / 5f;
            float radius = 0.18f;
            tentacle.transform.localPosition = new Vector3(Mathf.Cos(angle) * radius, -0.45f, Mathf.Sin(angle) * radius);
            tentacle.transform.localScale = new Vector3(0.05f, 0.35f + i * 0.03f, 0.05f);
            Destroy(tentacle.GetComponent<Collider>());
        }

        return root;
    }

    void CreateSeaweedCorridor(float leftX, float rightX, float zStart, float zEnd, float spacing)
    {
        for (float z = zStart; z <= zEnd; z += spacing)
        {
            CreateSeaweedObstacle(new Vector3(leftX + Random.Range(-0.3f, 0.3f), 0f, z), Random.Range(10f, 14f), Random.Range(-10f, 10f), Random.Range(0.95f, 1.2f));
            CreateSeaweedObstacle(new Vector3(rightX + Random.Range(-0.3f, 0.3f), 0f, z), Random.Range(10f, 14f), Random.Range(-10f, 10f), Random.Range(0.95f, 1.2f));
            if (Random.value > 0.2f)
                CreateSeaweedObstacle(new Vector3(leftX - 0.95f + Random.Range(-0.2f, 0.2f), 0f, z + Random.Range(-0.35f, 0.35f)), Random.Range(9.5f, 13f), Random.Range(-8f, 8f), Random.Range(0.8f, 1.05f));
            if (Random.value > 0.2f)
                CreateSeaweedObstacle(new Vector3(rightX + 0.95f + Random.Range(-0.2f, 0.2f), 0f, z + Random.Range(-0.35f, 0.35f)), Random.Range(9.5f, 13f), Random.Range(-8f, 8f), Random.Range(0.8f, 1.05f));
        }
    }

    void CreateSeaweedCrossBarrier(Vector3 center, int count, float spacing, bool gapOnLeft)
    {
        for (int i = 0; i < count; i++)
        {
            float x = center.x - ((count - 1) * spacing * 0.5f) + i * spacing;
            if (gapOnLeft && i < 2) continue;
            if (!gapOnLeft && i > count - 3) continue;
            CreateSeaweedObstacle(new Vector3(x, 0f, center.z + Mathf.Sin(i * 0.7f) * 0.5f), Random.Range(10f, 13.5f), Random.Range(-14f, 14f), Random.Range(0.95f, 1.25f));
        }
    }

    void CreateSeaweedGate(Vector3 center, float openingWidth)
    {
        float leftEdge = center.x - openingWidth * 0.5f - 2.2f;
        float rightEdge = center.x + openingWidth * 0.5f + 2.2f;
        for (int i = 0; i < 4; i++)
        {
            CreateSeaweedObstacle(new Vector3(leftEdge - i * 0.9f, 0f, center.z + Random.Range(-0.8f, 0.8f)), Random.Range(10.5f, 14f), Random.Range(-12f, 12f), Random.Range(1.0f, 1.25f));
            CreateSeaweedObstacle(new Vector3(rightEdge + i * 0.9f, 0f, center.z + Random.Range(-0.8f, 0.8f)), Random.Range(10.5f, 14f), Random.Range(-12f, 12f), Random.Range(1.0f, 1.25f));
        }
    }

    void CreateSeaweedObstacle(Vector3 position, float height, float tilt, float thickness)
    {
        GameObject obstacle = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        obstacle.name = "SeaweedObstacle";
        obstacle.transform.position = new Vector3(position.x, -2.0f + height * 0.5f, position.z);
        obstacle.transform.localScale = new Vector3(thickness, height * 0.5f, thickness);
        obstacle.transform.rotation = Quaternion.Euler(tilt, Random.Range(0f, 360f), tilt * 0.3f);
        obstacle.AddComponent<Obstacle>();
        obstacle.AddComponent<SeaweedSway>();

        Renderer r = obstacle.GetComponent<Renderer>();
        if (r != null)
        {
            Color seaweed = Color.Lerp(new Color(0.04f, 0.23f, 0.08f), new Color(0.12f, 0.42f, 0.18f), Random.value);
            r.material = WebGLSafeMaterials.CreateLit(seaweed);
        }
    }

    void BuildFallbackScene()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject camObj = new GameObject("Main Camera");
            cam = camObj.AddComponent<Camera>();
            cam.tag = "MainCamera";
        }

        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.35f, 0f, 0.35f);
        cam.transform.position = new Vector3(0f, 4f, -12f);
        cam.transform.LookAt(Vector3.zero);

        GameObject lightGO = new GameObject("Directional Light");
        Light light = lightGO.AddComponent<Light>();
        light.type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "BootstrapFailureMarker";
        cube.transform.position = Vector3.zero;
        cube.GetComponent<Renderer>().material = WebGLSafeMaterials.CreateLit(Color.white);
    }
}
