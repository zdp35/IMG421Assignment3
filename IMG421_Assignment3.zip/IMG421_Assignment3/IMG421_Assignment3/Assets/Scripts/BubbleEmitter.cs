using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public class BubbleEmitter : MonoBehaviour
{
    ParticleSystem ps;
    ParticleSystem.EmissionModule emission;
    ParticleSystem.ColorOverLifetimeModule colorOverLifetime;

    void Awake()
    {
        ps = GetComponent<ParticleSystem>();

        if (ps == null)
        {
            Debug.LogError("BubbleEmitter: No ParticleSystem found.");
            enabled = false;
            return;
        }

        var main = ps.main;
        emission = ps.emission;
        colorOverLifetime = ps.colorOverLifetime;

        main.playOnAwake = true;
        main.loop = true;
        main.startLifetime = new ParticleSystem.MinMaxCurve(0.8f, 1.4f);
        main.startSpeed = new ParticleSystem.MinMaxCurve(0.15f, 0.45f);
        main.startSize = new ParticleSystem.MinMaxCurve(0.03f, 0.08f);
        main.gravityModifier = -0.02f;
        main.simulationSpace = ParticleSystemSimulationSpace.World;

        emission.rateOverTime = 4f;

        var shape = ps.shape;
        shape.enabled = true;
        shape.shapeType = ParticleSystemShapeType.Cone;
        shape.angle = 8f;
        shape.radius = 0.05f;
        shape.position = new Vector3(0f, -0.2f, -0.15f);

        var noise = ps.noise;
        noise.enabled = true;
        noise.strength = 0.1f;
        noise.frequency = 0.5f;

        colorOverLifetime.enabled = true;

        Gradient g = new Gradient();
        g.SetKeys(
            new[]
            {
                new GradientColorKey(new Color(0.75f, 0.92f, 1f), 0f),
                new GradientColorKey(Color.white, 1f)
            },
            new[]
            {
                new GradientAlphaKey(0f, 0f),
                new GradientAlphaKey(0.45f, 0.15f),
                new GradientAlphaKey(0f, 1f)
            }
        );

        colorOverLifetime.color = new ParticleSystem.MinMaxGradient(g);

        ParticleSystemRenderer psRenderer = GetComponent<ParticleSystemRenderer>();
        if (psRenderer != null)
        {
            psRenderer.material = WebGLSafeMaterials.CreateUnlit(Color.white);
            psRenderer.renderMode = ParticleSystemRenderMode.Billboard;
        }
    }

    public void SetPulseAmount(float pulse)
    {
        emission.rateOverTime = Mathf.Lerp(2f, 7f, pulse);
    }

    public void ApplyColorFromRenderer()
    {
        if (ps == null) return;

        Renderer r = GetComponentInChildren<Renderer>();
        if (r == null) return;

        Color c = Color.Lerp(r.material.color, Color.white, 0.6f);

        Gradient g = new Gradient();
        g.SetKeys(
            new[]
            {
                new GradientColorKey(c, 0f),
                new GradientColorKey(Color.white, 1f)
            },
            new[]
            {
                new GradientAlphaKey(0f, 0f),
                new GradientAlphaKey(0.35f, 0.2f),
                new GradientAlphaKey(0f, 1f)
            }
        );

        colorOverLifetime.color = new ParticleSystem.MinMaxGradient(g);
    }
}
