using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(Neighborhood))]
public class Boid : MonoBehaviour
{
    public Rigidbody rigid;
    Neighborhood neighborhood;
    public float separationWeight = 0.55f;
    public float maxTurnDegreesPerSecond = 540f;
    public float wanderWeight = 0.18f;

    Vector3 wanderAxis;
    float pulsePhase;
    BubbleEmitter bubbleEmitter;

    public Vector3 pos { get => transform.position; set => transform.position = value; }

    void Awake()
    {
        rigid = GetComponent<Rigidbody>();
        neighborhood = GetComponent<Neighborhood>();
        rigid.useGravity = false;
        rigid.constraints = RigidbodyConstraints.FreezeRotation;
        rigid.interpolation = RigidbodyInterpolation.Interpolate;
        wanderAxis = Random.onUnitSphere;
        pulsePhase = Random.Range(0f, Mathf.PI * 2f);
        bubbleEmitter = GetComponent<BubbleEmitter>();
    }

    void Start()
    {
        if (Spawner.S == null){ Debug.LogError("Boid: Spawner not initialized."); enabled = false; return; }
        pos = Attractor.POS + Random.insideUnitSphere * Spawner.S.spawnRadius;
        rigid.velocity = Random.onUnitSphere * Spawner.S.velocity;

        Color bodyColor = Random.ColorHSV(0.42f, 0.62f, 0.55f, 0.9f, 0.82f, 1f);
        Renderer[] renderers = GetComponentsInChildren<Renderer>();
        for (int i = 0; i < renderers.Length; i++)
        {
            Color renderColor = bodyColor;
            if (renderers[i].gameObject.name.Contains("Tentacle"))
                renderColor = Color.Lerp(bodyColor, Color.white, 0.25f);

            renderers[i].material = WebGLSafeMaterials.CreateLit(renderColor, true, 0.45f);
        }

        BoidTrail bt = GetComponent<BoidTrail>();
        if (bt != null) bt.ApplyColorFromRenderer();
        if (bubbleEmitter != null) bubbleEmitter.ApplyColorFromRenderer();
        LookAhead();
    }

    void FixedUpdate()
    {
        Spawner spn = Spawner.S;
        if (spn == null) return;

        float pulse = Mathf.Sin(Time.time * 2.2f + pulsePhase) * 0.5f + 0.5f;
        float pulseSpeed = Mathf.Lerp(spn.velocity * 0.72f, spn.velocity * 1.12f, pulse);

        Vector3 vel = rigid.velocity.sqrMagnitude > 0.001f ? rigid.velocity.normalized * pulseSpeed : transform.forward * pulseSpeed;
        Vector3 velAlign = neighborhood.avgVel;
        if (velAlign != Vector3.zero) velAlign = velAlign.normalized * pulseSpeed;
        Vector3 velCenter = neighborhood.avgPos;
        if (velCenter != Vector3.zero) velCenter = (velCenter - pos).normalized * pulseSpeed;
        Vector3 sep = neighborhood.separation;
        Vector3 velSep = sep != Vector3.zero ? sep.normalized * pulseSpeed : Vector3.zero;

        Vector3 delta = Attractor.POS - pos;
        bool attracted = delta.magnitude > spn.attractPushDist;
        Vector3 velAttract = delta.normalized * pulseSpeed;
        Vector3 velObstacle = GetObstacleAvoidanceVector();

        Vector3 currentDir = rigid.velocity.sqrMagnitude > 0.001f ? rigid.velocity.normalized : transform.forward;
        Vector3 velWander = Vector3.Cross(currentDir, wanderAxis).normalized * pulseSpeed;
        wanderAxis = Vector3.Slerp(wanderAxis, Random.onUnitSphere, 0.008f);

        float desiredY = Mathf.Clamp(Attractor.POS.y + Mathf.Sin(transform.position.x * 0.18f) * 0.7f, 2.8f, 8.0f);
        Vector3 velHeight = new Vector3(0f, Mathf.Clamp(desiredY - pos.y, -1f, 1f), 0f).normalized * pulseSpeed;

        float fdt = Time.fixedDeltaTime;
        if (velAlign != Vector3.zero) vel = Vector3.Lerp(vel, velAlign, spn.velMatching * fdt);
        if (velCenter != Vector3.zero) vel = Vector3.Lerp(vel, velCenter, spn.flockCentering * fdt);
        if (velSep != Vector3.zero) vel = Vector3.Lerp(vel, velSep, separationWeight * fdt);
        if (velObstacle != Vector3.zero) vel = Vector3.Lerp(vel, velObstacle, spn.obstacleAvoidWeight * fdt);
        if (velHeight != Vector3.zero) vel = Vector3.Lerp(vel, velHeight, 0.5f * fdt);
        if (velAttract != Vector3.zero) vel = attracted ? Vector3.Lerp(vel, velAttract, spn.attractPull * fdt) : Vector3.Lerp(vel, -velAttract, spn.attractPush * fdt);
        vel = Vector3.Lerp(vel, velWander, wanderWeight * fdt);

        Vector3 desired = vel.normalized * pulseSpeed;
        Vector3 current = rigid.velocity.sqrMagnitude > 0.0001f ? rigid.velocity.normalized * pulseSpeed : desired;
        float maxRadians = Mathf.Deg2Rad * maxTurnDegreesPerSecond * fdt;
        Vector3 limited = Vector3.RotateTowards(current, desired, maxRadians, 0f);

        rigid.velocity = limited.normalized * pulseSpeed;
        if (bubbleEmitter != null) bubbleEmitter.SetPulseAmount(pulse);
        LookAhead();
    }

    Vector3 GetObstacleAvoidanceVector()
    {
        Spawner spn = Spawner.S;
        if (spn == null) return Vector3.zero;

        Vector3 forward = rigid.velocity.sqrMagnitude > 0.001f ? rigid.velocity.normalized : transform.forward;
        Vector3 right = transform.right;

        Vector3 leftOrigin = pos - right * spn.obstacleSideOffset;
        Vector3 centerOrigin = pos;
        Vector3 rightOrigin = pos + right * spn.obstacleSideOffset;

        RaycastHit hitL, hitC, hitR;
        bool leftHit = Physics.Raycast(leftOrigin, forward, out hitL, spn.obstacleDetectDistance, spn.obstacleLayerMask, QueryTriggerInteraction.Ignore);
        bool centerHit = Physics.Raycast(centerOrigin, forward, out hitC, spn.obstacleDetectDistance, spn.obstacleLayerMask, QueryTriggerInteraction.Ignore);
        bool rightHit = Physics.Raycast(rightOrigin, forward, out hitR, spn.obstacleDetectDistance, spn.obstacleLayerMask, QueryTriggerInteraction.Ignore);

        if (!leftHit && !centerHit && !rightHit) return Vector3.zero;

        RaycastHit chosen = hitC;
        if (centerHit) chosen = hitC;
        else if (leftHit && rightHit) chosen = hitL.distance < hitR.distance ? hitL : hitR;
        else if (leftHit) chosen = hitL;
        else chosen = hitR;

        if (chosen.collider == null) return Vector3.zero;
        Obstacle obstacle = chosen.collider.GetComponent<Obstacle>();
        if (obstacle == null) return Vector3.zero;

        Vector3 closest = chosen.collider.ClosestPoint(pos);
        Vector3 away = (pos - closest).normalized;
        if (away == Vector3.zero) away = Vector3.Cross(forward, Vector3.up).normalized;

        Vector3 tangent = Vector3.Cross(Vector3.up, chosen.normal).normalized;
        if (Vector3.Dot(tangent, rigid.velocity) < 0f) tangent *= -1f;

        Vector3 avoidDir = (away * 0.9f + tangent * 0.75f + Vector3.up * 0.08f).normalized;
        return avoidDir * Spawner.S.velocity;
    }

    void LookAhead()
    {
        if (rigid.velocity.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.LookRotation(rigid.velocity.normalized, Vector3.up);
    }
}
