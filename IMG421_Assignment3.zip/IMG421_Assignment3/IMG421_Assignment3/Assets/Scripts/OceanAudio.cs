using UnityEngine;

public class OceanAudio : MonoBehaviour
{
    AudioSource ambientSource;
    AudioSource musicSource;

    void Start()
    {
        ambientSource = gameObject.AddComponent<AudioSource>();
        ambientSource.loop = true;
        ambientSource.playOnAwake = true;
        ambientSource.volume = 0.18f;

        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.loop = true;
        musicSource.playOnAwake = true;
        musicSource.volume = 0.12f;

        AudioClip ambient = Resources.Load<AudioClip>("Audio/ocean_ambient");
        if (ambient != null){ ambientSource.clip = ambient; ambientSource.Play(); }

        AudioClip music = Resources.Load<AudioClip>("Audio/ocean_music");
        if (music != null){ musicSource.clip = music; musicSource.Play(); }
    }
}
