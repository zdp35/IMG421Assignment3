using UnityEngine;

public class DynamicObstacleSpawner : MonoBehaviour
{
    public Camera targetCamera;
    public KeyCode spawnKey = KeyCode.Mouse0;

    void Update()
    {
        if (!Input.GetKeyDown(spawnKey)) return;
        Camera cam = targetCamera != null ? targetCamera : Camera.main;
        if (cam == null) return;

        Ray ray = cam.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 300f))
        {
            if (!hit.collider.gameObject.name.Contains("Seafloor")) return;
            SpawnSeaweedAt(hit.point);
        }
    }

    void SpawnSeaweedAt(Vector3 point)
    {
        float height = Random.Range(10f, 13f);
        float thickness = Random.Range(0.9f, 1.2f);
        GameObject obstacle = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        obstacle.name = "DynamicSeaweedObstacle";
        obstacle.transform.position = new Vector3(point.x, -2.0f + height * 0.5f, point.z);
        obstacle.transform.localScale = new Vector3(thickness, height * 0.5f, thickness);
        obstacle.transform.rotation = Quaternion.Euler(Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(-6f, 6f));
        obstacle.AddComponent<Obstacle>();
        obstacle.AddComponent<SeaweedSway>();

        Renderer r = obstacle.GetComponent<Renderer>();
        if (r != null)
        {
            Color seaweed = Color.Lerp(new Color(0.04f, 0.23f, 0.08f), new Color(0.12f, 0.42f, 0.18f), Random.value);
            r.material = WebGLSafeMaterials.CreateLit(seaweed);
        }
    }
}
