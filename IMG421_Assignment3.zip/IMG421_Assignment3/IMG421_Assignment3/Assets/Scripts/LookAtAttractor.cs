using UnityEngine;

public class LookAtAttractor : MonoBehaviour
{
    public Vector3 offset = new Vector3(0f, 10f, -22f);
    public float followSpeed = 2.5f;

    void LateUpdate()
    {
        Vector3 desired = Attractor.POS + offset;
        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * Time.deltaTime);
        transform.LookAt(Attractor.POS + new Vector3(0f, 1f, 0f));
    }
}
