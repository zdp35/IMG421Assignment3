using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public float avoidanceRadius = 3f;
}
