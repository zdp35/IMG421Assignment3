using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public static Spawner S;
    public static List<Boid> boids;
    public GameObject boidPrefab;
    public Transform boidAnchor;

    [Header("Spawn")]
    public int numBoids = 36;
    public float spawnRadius = 12f;
    public float spawnDelay = 0.03f;

    [Header("Flocking")]
    public float velocity = 8.2f;
    public float neighborDist = 8.5f;
    public float collDist = 1.15f;
    public float velMatching = 1.45f;
    public float flockCentering = 1.85f;
    public float collAvoid = 2.2f;

    [Header("Attractor")]
    public float attractPull = 1.7f;
    public float attractPush = 0.8f;
    public float attractPushDist = 2.0f;

    [Header("Obstacle Avoidance")]
    public float obstacleAvoidWeight = 4.6f;
    public float obstacleDetectDistance = 4.4f;
    public float obstacleSideOffset = 0.42f;
    public LayerMask obstacleLayerMask = ~0;

    void Awake()
    {
        S = this;
        boids = new List<Boid>();
    }

    void Start()
    {
        InstantiateBoid();
    }

    public void InstantiateBoid()
    {
        if (boidPrefab == null || boidAnchor == null)
        {
            Debug.LogError("Spawner missing boidPrefab or boidAnchor.");
            return;
        }

        GameObject go = Instantiate(boidPrefab, boidAnchor);
        go.name = "Jellyfish";
        go.SetActive(true);

        Boid b = go.GetComponent<Boid>();
        if (b != null && !boids.Contains(b))
            boids.Add(b);

        if (boids.Count < numBoids)
            Invoke(nameof(InstantiateBoid), spawnDelay);
    }
}
