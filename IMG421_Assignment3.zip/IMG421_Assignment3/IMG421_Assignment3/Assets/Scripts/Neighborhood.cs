using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SphereCollider))]
public class Neighborhood : MonoBehaviour
{
    public List<Boid> neighbors;
    SphereCollider coll;

    void Awake()
    {
        neighbors = new List<Boid>();
        coll = GetComponent<SphereCollider>();
        coll.isTrigger = true;
    }

    void FixedUpdate()
    {
        if (Spawner.S == null) return;
        float desired = Spawner.S.neighborDist * 0.5f;
        if (!Mathf.Approximately(coll.radius, desired)) coll.radius = desired;
    }

    void OnTriggerEnter(Collider other)
    {
        Boid b = other.GetComponent<Boid>();
        if (b != null && !neighbors.Contains(b)) neighbors.Add(b);
    }

    void OnTriggerExit(Collider other)
    {
        Boid b = other.GetComponent<Boid>();
        if (b != null) neighbors.Remove(b);
    }

    public Vector3 avgPos
    {
        get
        {
            if (neighbors.Count == 0) return Vector3.zero;
            Vector3 sum = Vector3.zero;
            foreach (Boid b in neighbors) sum += b.pos;
            return sum / neighbors.Count;
        }
    }

    public Vector3 avgVel
    {
        get
        {
            if (neighbors.Count == 0) return Vector3.zero;
            Vector3 sum = Vector3.zero;
            foreach (Boid b in neighbors) sum += b.rigid.velocity;
            return sum / neighbors.Count;
        }
    }

    public Vector3 separation
    {
        get
        {
            if (Spawner.S == null || neighbors.Count == 0) return Vector3.zero;
            Vector3 force = Vector3.zero;
            int count = 0;
            float maxDistSq = Spawner.S.neighborDist * Spawner.S.neighborDist;

            foreach (Boid b in neighbors)
            {
                Vector3 d = transform.position - b.pos;
                float d2 = d.sqrMagnitude;
                if (d2 < 0.0001f || d2 > maxDistSq) continue;
                force += d.normalized / Mathf.Max(d2, 0.25f);
                count++;
            }

            if (count == 0) return Vector3.zero;
            return force / count;
        }
    }
}
