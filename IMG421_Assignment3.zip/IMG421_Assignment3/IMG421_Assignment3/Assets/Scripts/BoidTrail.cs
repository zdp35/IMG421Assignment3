using UnityEngine;

[RequireComponent(typeof(TrailRenderer))]
public class BoidTrail : MonoBehaviour
{
    public float trailTime = 0.85f, width = 0.18f, minVertexDistance = 0.04f;
    TrailRenderer tr;

    void Awake()
    {
        tr = GetComponent<TrailRenderer>();
        tr.time = trailTime;
        tr.minVertexDistance = minVertexDistance;
        tr.widthMultiplier = width;
        tr.widthCurve = new AnimationCurve(
            new Keyframe(0f, 0.3f),
            new Keyframe(0.18f, 1.1f),
            new Keyframe(0.55f, 0.55f),
            new Keyframe(1f, 0f)
        );
        tr.material = WebGLSafeMaterials.CreateUnlit(Color.white);
        tr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        tr.receiveShadows = false;
        tr.numCornerVertices = 6;
        tr.numCapVertices = 6;
        tr.alignment = LineAlignment.View;
    }

    void Start(){ ApplyColorFromRenderer(); }

    public void ApplyColorFromRenderer()
    {
        Renderer r = GetComponentInChildren<Renderer>();
        if (r == null || tr == null) return;
        Color c = r.material.color;
        Color bright = Color.Lerp(c, Color.white, 0.45f);
        Color deep = Color.Lerp(c, new Color(0.05f, 0.16f, 0.28f), 0.45f);

        Gradient g = new Gradient();
        g.SetKeys(
            new[] { new GradientColorKey(bright, 0f), new GradientColorKey(c, 0.25f), new GradientColorKey(deep, 1f) },
            new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(0.9f, 0.1f), new GradientAlphaKey(0.4f, 0.7f), new GradientAlphaKey(0f, 1f) }
        );
        tr.colorGradient = g;
    }
}
