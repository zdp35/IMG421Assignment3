using UnityEngine;

public static class WebGLSafeMaterials
{
    public static Shader FindBestLitShader()
    {
        Shader shader = Shader.Find("Standard");
        if (shader != null) return shader;

        shader = Shader.Find("Legacy Shaders/Diffuse");
        if (shader != null) return shader;

        shader = Shader.Find("Sprites/Default");
        if (shader != null) return shader;

        return null;
    }

    public static Shader FindBestUnlitShader()
    {
        Shader shader = Shader.Find("Sprites/Default");
        if (shader != null) return shader;

        shader = Shader.Find("Unlit/Color");
        if (shader != null) return shader;

        return FindBestLitShader();
    }

    public static Material CreateLit(Color color, bool emission = false, float emissionStrength = 0.5f)
    {
        Shader shader = FindBestLitShader();
        Material mat = shader != null ? new Material(shader) : new Material(Shader.Find("Sprites/Default"));
        mat.color = color;

        if (emission && mat.HasProperty("_EmissionColor"))
        {
            mat.EnableKeyword("_EMISSION");
            mat.SetColor("_EmissionColor", color * emissionStrength);
        }

        return mat;
    }

    public static Material CreateUnlit(Color color)
    {
        Shader shader = FindBestUnlitShader();
        Material mat = shader != null ? new Material(shader) : new Material(Shader.Find("Sprites/Default"));
        mat.color = color;
        return mat;
    }
}
