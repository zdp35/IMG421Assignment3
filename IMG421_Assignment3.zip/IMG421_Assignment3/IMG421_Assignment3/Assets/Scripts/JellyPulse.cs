using UnityEngine;

public class JellyPulse : MonoBehaviour
{
    public Transform bell;
    public Transform[] tentacles;
    public float pulseSpeed = 2.2f, bellSquish = 0.12f, tentacleWave = 0.15f;

    Vector3 bellBaseScale;
    Vector3[] tentacleBaseScales;

    void Start()
    {
        if (bell == null)
        {
            Transform found = transform.Find("Bell");
            if (found != null) bell = found;
        }
        if (bell != null) bellBaseScale = bell.localScale;

        if (tentacles == null || tentacles.Length == 0)
        {
            Transform root = transform.Find("Tentacles");
            if (root != null)
            {
                tentacles = new Transform[root.childCount];
                for (int i = 0; i < root.childCount; i++) tentacles[i] = root.GetChild(i);
            }
        }

        tentacleBaseScales = new Vector3[tentacles.Length];
        for (int i = 0; i < tentacles.Length; i++)
            if (tentacles[i] != null) tentacleBaseScales[i] = tentacles[i].localScale;
    }

    void Update()
    {
        float wave = (Mathf.Sin(Time.time * pulseSpeed + transform.GetInstanceID() * 0.17f) + 1f) * 0.5f;

        if (bell != null)
        {
            bell.localScale = new Vector3(
                bellBaseScale.x * (1f + bellSquish * wave),
                bellBaseScale.y * (1f - bellSquish * wave),
                bellBaseScale.z * (1f + bellSquish * wave)
            );
        }

        for (int i = 0; i < tentacles.Length; i++)
        {
            if (tentacles[i] == null) continue;
            Vector3 s = tentacleBaseScales[i];
            float localWave = Mathf.Sin(Time.time * pulseSpeed * 1.4f + i * 0.6f + transform.GetInstanceID() * 0.11f);
            tentacles[i].localScale = new Vector3(s.x, s.y * (1f + tentacleWave * localWave), s.z);
            tentacles[i].localRotation = Quaternion.Euler(localWave * 8f, 0f, localWave * 8f);
        }
    }
}
