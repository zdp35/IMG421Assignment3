using UnityEngine;

public class SeaweedSway : MonoBehaviour
{
    public float speed = 1.25f, angle = 8f, secondaryAngle = 4f;
    float phase;
    Vector3 baseEuler;

    void Start(){ phase = Random.Range(0f, Mathf.PI * 2f); baseEuler = transform.rotation.eulerAngles; }

    void Update()
    {
        float sway = Mathf.Sin(Time.time * speed + phase) * angle;
        float sway2 = Mathf.Cos(Time.time * (speed * 0.73f) + phase) * secondaryAngle;
        transform.rotation = Quaternion.Euler(baseEuler.x + sway, baseEuler.y, baseEuler.z + sway2);
    }
}
