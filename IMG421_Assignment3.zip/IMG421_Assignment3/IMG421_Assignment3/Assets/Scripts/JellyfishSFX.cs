using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class JellyfishSFX : MonoBehaviour
{
    AudioSource source;
    float nextPulseTime;

    void Awake()
    {
        source = GetComponent<AudioSource>();
        source.playOnAwake = false;
        source.spatialBlend = 0.6f;
        source.volume = 0.06f;
        source.minDistance = 2f;
        source.maxDistance = 18f;
    }

    void Start(){ nextPulseTime = Time.time + Random.Range(0.2f, 1.6f); }

    void Update()
    {
        if (Time.time >= nextPulseTime)
        {
            AudioClip clip = Resources.Load<AudioClip>("Audio/jelly_pulse");
            if (clip != null)
            {
                source.pitch = Random.Range(0.88f, 1.16f);
                source.PlayOneShot(clip, 1f);
            }
            nextPulseTime = Time.time + Random.Range(1.6f, 3.2f);
        }
    }
}
