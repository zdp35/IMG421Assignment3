using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenu : MonoBehaviour
{
    public string sceneToLoad = "JellyfishBoids";
    bool isLoading;

    void Update()
    {
        if (isLoading) return;

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            StartGame();
    }

    void StartGame()
    {
        if (isLoading) return;
        isLoading = true;
        SceneManager.LoadScene(sceneToLoad);
    }

    void OnGUI()
    {
        float w = Screen.width, h = Screen.height;
        GUI.color = new Color(0.88f, 0.97f, 1f);

        GUIStyle title = new GUIStyle(GUI.skin.label);
        title.alignment = TextAnchor.MiddleCenter;
        title.fontSize = Mathf.RoundToInt(h * 0.055f);
        title.fontStyle = FontStyle.Bold;

        GUIStyle body = new GUIStyle(GUI.skin.label);
        body.alignment = TextAnchor.MiddleCenter;
        body.fontSize = Mathf.RoundToInt(h * 0.022f);
        body.wordWrap = true;

        GUIStyle button = new GUIStyle(GUI.skin.button);
        button.fontSize = Mathf.RoundToInt(h * 0.024f);
        button.fontStyle = FontStyle.Bold;

        GUI.Label(new Rect(w * 0.1f, h * 0.18f, w * 0.8f, h * 0.1f), "Jellyfish Drift", title);
        GUI.Label(new Rect(w * 0.18f, h * 0.31f, w * 0.64f, h * 0.18f),
            "Guide a glowing bloom of jellyfish through underwater seaweed barriers.\nPress SPACE / ENTER or click START.",
            body
        );

        if (GUI.Button(new Rect(w * 0.4f, h * 0.58f, w * 0.2f, h * 0.08f), "START", button))
            StartGame();
    }
}
